package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [PrinterEntity::class, TimelapseEntity::class],
    version = 1,
    exportSchema = false
)
abstract class PrintLapseDatabase : RoomDatabase() {
    abstract fun dao(): PrintLapseDao

    companion object {
        @Volatile
        private var INSTANCE: PrintLapseDatabase? = null

        fun getInstance(context: Context): PrintLapseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PrintLapseDatabase::class.java,
                    "printlapse_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
