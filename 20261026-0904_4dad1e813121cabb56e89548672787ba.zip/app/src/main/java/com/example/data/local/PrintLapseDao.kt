package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PrintLapseDao {
    @Query("SELECT * FROM printers ORDER BY isDefault DESC, id DESC")
    fun getAllPrinters(): Flow<List<PrinterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrinter(printer: PrinterEntity): Long

    @Update
    suspend fun updatePrinter(printer: PrinterEntity)

    @Query("SELECT * FROM timelapses ORDER BY createdAt DESC")
    fun getAllTimelapses(): Flow<List<TimelapseEntity>>

    @Query("SELECT * FROM timelapses WHERE id = :id")
    suspend fun getTimelapseById(id: Long): TimelapseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimelapse(timelapse: TimelapseEntity): Long

    @Query("DELETE FROM timelapses WHERE id = :id")
    suspend fun deleteTimelapse(id: Long)
}
