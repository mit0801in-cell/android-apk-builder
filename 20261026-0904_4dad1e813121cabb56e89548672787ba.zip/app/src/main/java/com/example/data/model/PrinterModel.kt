package com.example.data.model

enum class BambuPrinterType(val displayName: String, val hasEnclosure: Boolean) {
    X1_CARBON("Bambu Lab X1-Carbon", true),
    P1S("Bambu Lab P1S", true),
    P1P("Bambu Lab P1P", false),
    A1("Bambu Lab A1", false),
    A1_MINI("Bambu Lab A1 Mini", false),
    CUSTOM("Custom / OctoPrint", false)
}

enum class PrintStatus(val labelJp: String) {
    IDLE("待機中"),
    PREHEATING("予熱中"),
    CALIBRATING("ベッドレベリング中"),
    PRINTING("造形中 (タイムラプス記録中)"),
    PAUSED("一時停止"),
    COMPLETED("プリント完了"),
    TIMELAPSE_GENERATING("タイムラプス自動生成中")
}

enum class TimelapseMode(val labelJp: String, val descJp: String) {
    SMOOTH("スムーズ (Smooth)", "ノズルをワイプタワーに退避させてブレのない美しい映像を撮影"),
    TRADITIONAL("標準 (Traditional)", "各レイヤー完了時の位置で高速撮影 (造形時間最短)")
}

data class PrintTelemetry(
    val status: PrintStatus = PrintStatus.IDLE,
    val jobName: String = "3D_Benchy_Speed.3mf",
    val progressPercent: Float = 0.52f,
    val currentLayer: Int = 182,
    val totalLayers: Int = 350,
    val nozzleTemp: Int = 220,
    val nozzleTargetTemp: Int = 220,
    val bedTemp: Int = 60,
    val bedTargetTemp: Int = 60,
    val chamberTemp: Int = 38,
    val printSpeedMmS: Int = 250,
    val remainingMinutes: Int = 21,
    val elapsedMinutes: Int = 23,
    val fanSpeedPercent: Int = 80,
    val timelapseFramesCount: Int = 182,
    val isAutoTimelapseEnabled: Boolean = true,
    val timelapseMode: TimelapseMode = TimelapseMode.SMOOTH,
    val filamentType: String = "PLA Basic (Bambu Cyan)"
)

data class NetworkTestResult(
    val isSuccess: Boolean = false,
    val ipReachable: Boolean = false,
    val mqttPortOpen: Boolean = false, // 8883
    val ftpPortOpen: Boolean = false,  // 990
    val latencyMs: Long = 0,
    val message: String = ""
)
