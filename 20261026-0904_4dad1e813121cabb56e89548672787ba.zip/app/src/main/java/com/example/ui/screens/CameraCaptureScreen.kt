package com.example.ui.screens

import android.content.Context
import android.os.Vibrator
import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.components.CameraXPreview
import com.example.ui.components.CyberHudOverlay
import com.example.ui.components.TimelapseCanvasViewer
import com.example.ui.theme.AmberBed
import com.example.ui.theme.BambuGreen
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PrintLapseViewModel
import kotlinx.coroutines.delay
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraCaptureScreen(
    viewModel: PrintLapseViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onNavigateBack()
    }

    val context = LocalContext.current
    val telemetry by viewModel.telemetry.collectAsState()

    var isCapturing by remember { mutableStateOf(false) }
    var capturedFrames by remember { mutableIntStateOf(18) }
    var intervalSec by remember { mutableIntStateOf(5) }
    var syncWithBambuLayer by remember { mutableStateOf(true) }
    var isTorchOn by remember { mutableStateOf(false) }
    var showGrid by remember { mutableStateOf(true) }
    var useFrontCamera by remember { mutableStateOf(false) }
    var previewModeCameraX by remember { mutableStateOf(true) }
    var activeImageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var lastPhotoSavedTime by remember { mutableStateOf("") }

    // Shutter capture trigger helper
    fun captureCurrentFrame() {
        capturedFrames++
        activeImageCapture?.let { capture ->
            val photoFile = File(context.cacheDir, "lapse_frame_${System.currentTimeMillis()}.jpg")
            val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()
            capture.takePicture(
                outputOptions,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                        lastPhotoSavedTime = "${photoFile.name} 保存"
                    }
                    override fun onError(exception: ImageCaptureException) {
                        Log.w("CameraCapture", "Frame save failed: ${exception.message}")
                    }
                }
            )
        }
    }

    // Interval / Bambu layer sync timer loop
    LaunchedEffect(isCapturing, intervalSec, syncWithBambuLayer) {
        if (isCapturing) {
            while (true) {
                delay(if (syncWithBambuLayer) 2400L else intervalSec * 1000L)
                captureCurrentFrame()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "CameraX プリンター撮影プレビュー",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (previewModeCameraX) "端末カメラ (CameraX)" else "シミュレーションプレビュー",
                        color = CyanNeon,
                        fontSize = 11.sp
                    )
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("camera_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
            },
            actions = {
                // Switch between Back / Front Camera
                IconButton(
                    onClick = { useFrontCamera = !useFrontCamera },
                    modifier = Modifier.testTag("flip_camera_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Cameraswitch,
                        contentDescription = "Switch Camera",
                        tint = TextPrimary
                    )
                }

                // Flash / Torch toggle
                IconButton(
                    onClick = { isTorchOn = !isTorchOn },
                    modifier = Modifier.testTag("torch_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Torch",
                        tint = if (isTorchOn) AmberBed else TextSecondary
                    )
                }

                // HUD & Grid overlay toggle
                IconButton(
                    onClick = { showGrid = !showGrid },
                    modifier = Modifier.testTag("grid_toggle_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.GridOn,
                        contentDescription = "Grid",
                        tint = if (showGrid) CyanNeon else TextSecondary
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Camera Viewfinder Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .border(2.dp, if (isCapturing) BambuGreen else DarkSurfaceBorder, RoundedCornerShape(16.dp))
                    .background(Color(0xFF070B10))
            ) {
                if (previewModeCameraX) {
                    // Real CameraX Preview
                    CameraXPreview(
                        isTorchOn = isTorchOn,
                        useFrontCamera = useFrontCamera,
                        onImageCaptureCreated = { activeImageCapture = it },
                        onFallbackMode = { previewModeCameraX = false },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    // Fallback simulated 3D model render
                    TimelapseCanvasViewer(
                        currentFrame = (capturedFrames * 4).coerceAtMost(350),
                        totalFrames = 350,
                        filter = com.example.data.model.TimelapseFilter.ORIGINAL,
                        mode = telemetry.timelapseMode,
                        modelName = telemetry.jobName,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Alignment Crosshair & 3D Bed Level Overlay
                if (showGrid) {
                    CyberHudOverlay(
                        modelName = "CAM-X: ${telemetry.jobName}",
                        currentLayer = capturedFrames,
                        totalLayers = telemetry.totalLayers,
                        nozzleTemp = telemetry.nozzleTemp,
                        bedTemp = telemetry.bedTemp,
                        speedMmS = telemetry.printSpeedMmS,
                        timelapseMode = telemetry.timelapseMode,
                        filament = telemetry.filamentType,
                        elapsedFormatted = "${capturedFrames * intervalSec}s"
                    )
                }

                // Live Camera Mode Toggle Tag (Top Left)
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xDD000000))
                            .clickable { previewModeCameraX = !previewModeCameraX }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                tint = CyanNeon,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (previewModeCameraX) "CameraX 実カメラ" else "CADシミュレーター",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Shutter active recording pill (Top Center)
                if (isCapturing) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 12.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xEE000000))
                            .border(1.dp, BambuGreen, RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (syncWithBambuLayer) "Bambu Studio レイヤー連動撮影中" else "${intervalSec}秒間隔撮影中",
                            color = BambuGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Capture Controls Panel
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CameraX 蓄積フレーム: $capturedFrames 枚",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "生成動画長: 約 ${(capturedFrames / 30f).coerceAtLeast(0.5f)} 秒 (30fps)",
                                color = CyanNeon,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Shutter Start / Stop Button
                        Button(
                            onClick = {
                                isCapturing = !isCapturing
                                if (isCapturing) {
                                    captureCurrentFrame()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isCapturing) Color(0xFFEF4444) else BambuGreen,
                                contentColor = if (isCapturing) Color.White else Color.Black
                            ),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier.testTag("camera_shutter_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (isCapturing) Icons.Default.Stop else Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isCapturing) "撮影停止" else "撮影開始", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Trigger Mode Switcher
                    Text(
                        text = "シャッタートリガー設定",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = syncWithBambuLayer,
                            onClick = { syncWithBambuLayer = true },
                            label = { Text("Bambuレイヤー同期") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BambuGreen,
                                selectedLabelColor = Color.Black
                            ),
                            modifier = Modifier.testTag("trigger_bambu_sync")
                        )

                        listOf(5, 10, 30).forEach { sec ->
                            FilterChip(
                                selected = !syncWithBambuLayer && intervalSec == sec,
                                onClick = {
                                    syncWithBambuLayer = false
                                    intervalSec = sec
                                },
                                label = { Text("${sec}秒間隔") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanNeon,
                                    selectedLabelColor = Color.Black
                                ),
                                modifier = Modifier.testTag("trigger_interval_${sec}s")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Generate Timelapse Button
                    Button(
                        onClick = {
                            isCapturing = false
                            viewModel.generateTimelapseNow()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_timelapse_from_cam_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF233242),
                            contentColor = TextPrimary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = BambuGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("撮影フレームからタイムラプスを自動生成")
                    }
                }
            }
        }
    }
}
