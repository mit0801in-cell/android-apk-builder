package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BambuPrinterType
import com.example.ui.theme.AmberBed
import com.example.ui.theme.BambuGreen
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.StatusFailed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PrintLapseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BambuConnectScreen(
    viewModel: PrintLapseViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onNavigateBack()
    }

    val printerIp by viewModel.printerIp.collectAsState()
    val printerAccessCode by viewModel.printerAccessCode.collectAsState()
    val printerSerial by viewModel.printerSerial.collectAsState()
    val printerModel by viewModel.printerModel.collectAsState()
    val networkResult by viewModel.networkTestResult.collectAsState()
    val isTesting by viewModel.isTestingConnection.collectAsState()

    var inputIp by remember(printerIp) { mutableStateOf(printerIp) }
    var inputAccessCode by remember(printerAccessCode) { mutableStateOf(printerAccessCode) }
    var inputSerial by remember(printerSerial) { mutableStateOf(printerSerial) }
    var selectedModel by remember(printerModel) { mutableStateOf(printerModel) }
    var modelDropdownExpanded by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Bambu Studio 連携設定",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("connect_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DarkBackground
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Bambu Studio Pairing Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(BambuGreen.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Router,
                                contentDescription = null,
                                tint = BambuGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Bambu プリンター LAN接続情報",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "同一Wi-Fiネットワーク上のBambu 3Dプリンターと同期",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Printer Model Dropdown
                    ExposedDropdownMenuBox(
                        expanded = modelDropdownExpanded,
                        onExpandedChange = { modelDropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedModel.displayName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("機種 (Bambu Lab Model)") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modelDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .testTag("printer_model_dropdown"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BambuGreen,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedLabelColor = BambuGreen,
                                unfocusedLabelColor = TextSecondary,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )

                        ExposedDropdownMenu(
                            expanded = modelDropdownExpanded,
                            onDismissRequest = { modelDropdownExpanded = false },
                            modifier = Modifier.background(DarkSurfaceElevated)
                        ) {
                            BambuPrinterType.entries.forEach { model ->
                                DropdownMenuItem(
                                    text = { Text(model.displayName, color = TextPrimary) },
                                    onClick = {
                                        selectedModel = model
                                        modelDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // IP Address Input
                    OutlinedTextField(
                        value = inputIp,
                        onValueChange = { inputIp = it },
                        label = { Text("プリンター IPアドレス") },
                        placeholder = { Text("例: 192.168.1.185") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_printer_ip"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BambuGreen,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedLabelColor = BambuGreen,
                            unfocusedLabelColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Access Code Input
                    OutlinedTextField(
                        value = inputAccessCode,
                        onValueChange = { inputAccessCode = it },
                        label = { Text("LANアクセスコード (Access Code)") },
                        placeholder = { Text("プリンター画面 [WLAN] に表示される数字/コード") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_access_code"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BambuGreen,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedLabelColor = BambuGreen,
                            unfocusedLabelColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Serial Number Input
                    OutlinedTextField(
                        value = inputSerial,
                        onValueChange = { inputSerial = it },
                        label = { Text("シリアル番号 (Serial Number)") },
                        placeholder = { Text("例: 01P00A381200384") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_serial_number"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BambuGreen,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedLabelColor = BambuGreen,
                            unfocusedLabelColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Test Network Button
                        Button(
                            onClick = {
                                viewModel.updatePrinterConfig(inputIp, inputAccessCode, inputSerial, selectedModel)
                                viewModel.runNetworkTest()
                            },
                            enabled = !isTesting,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("test_network_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF233242),
                                contentColor = CyanNeon
                            )
                        ) {
                            if (isTesting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = CyanNeon
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.NetworkCheck,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isTesting) "診断中..." else "接続テスト")
                        }

                        // Save Button
                        Button(
                            onClick = {
                                viewModel.updatePrinterConfig(inputIp, inputAccessCode, inputSerial, selectedModel)
                                viewModel.savePrinterConfig()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_config_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BambuGreen,
                                contentColor = Color.Black
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Save,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("設定保存", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Diagnostic Results box
                    AnimatedVisibility(visible = networkResult != null) {
                        networkResult?.let { result ->
                            Spacer(modifier = Modifier.height(12.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (result.isSuccess) Color(0xFF132219) else Color(0xFF281414))
                                    .border(
                                        1.dp,
                                        if (result.isSuccess) BambuGreen else StatusFailed,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (result.isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                                            contentDescription = null,
                                            tint = if (result.isSuccess) BambuGreen else StatusFailed,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (result.isSuccess) "接続テスト良好 (${result.latencyMs}ms)" else "接続エラー",
                                            color = if (result.isSuccess) BambuGreen else StatusFailed,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = result.message,
                                        color = TextPrimary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bambu Studio Slicer Settings Guide
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = null,
                            tint = AmberBed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Bambu Studio 側での連携設定手順",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    StepItem(
                        number = "1",
                        title = "タイムラプスモードを [Smooth] に設定",
                        desc = "Bambu Studio の [その他 (Others)] タブで「タイムラプス」を「スムーズ (Smooth)」に設定します。これによりノズルが各層でパージタワーへ自動退避し、映像のブレを防ぎます。"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    StepItem(
                        number = "2",
                        title = "LAN Only Mode (ローカルLANモード) の確認",
                        desc = "プリンター本体画面の「ネットワーク」設定で「LAN専用モード」をONにすると、アクセスコードとローカルIPが表示されます。"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    StepItem(
                        number = "3",
                        title = "自動生成タイムラプスの取得",
                        desc = "造形が完了すると、PrintLapseがMQTTとFTPポートを介して自動的にレイヤーフレームやSDカードのmp4を検出し、当アプリへタイムラプスを同期・生成します。"
                    )
                }
            }
        }
    }
}

@Composable
fun StepItem(number: String, title: String, desc: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(BambuGreen.copy(alpha = 0.2f))
                .border(1.dp, BambuGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = BambuGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }
    }
}
