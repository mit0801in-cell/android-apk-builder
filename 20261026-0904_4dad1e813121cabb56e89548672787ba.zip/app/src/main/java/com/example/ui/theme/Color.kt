package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bambu Lab & Modern 3D Maker Aesthetic Color Palette
val BambuGreen = Color(0xFF00AE42)
val BambuGreenLight = Color(0xFF00E659)
val BambuGreenDark = Color(0xFF007A2E)

val CyanNeon = Color(0xFF00E5FF)
val OrangeHotend = Color(0xFFFF6D00)
val AmberBed = Color(0xFFFFAB00)

val DarkBackground = Color(0xFF0F141C)
val DarkSurface = Color(0xFF161E29)
val DarkSurfaceElevated = Color(0xFF1F2B3A)
val DarkSurfaceBorder = Color(0xFF2C3B4E)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val StatusPrinting = Color(0xFF00AE42)
val StatusPreheating = Color(0xFFFFAB00)
val StatusPaused = Color(0xFF38BDF8)
val StatusFailed = Color(0xFFEF4444)
val StatusIdle = Color(0xFF94A3B8)
