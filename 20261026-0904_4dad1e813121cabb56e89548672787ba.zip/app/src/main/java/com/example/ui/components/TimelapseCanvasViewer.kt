package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.data.model.TimelapseFilter
import com.example.data.model.TimelapseMode
import kotlin.math.sin

@Composable
fun TimelapseCanvasViewer(
    currentFrame: Int,
    totalFrames: Int,
    filter: TimelapseFilter,
    mode: TimelapseMode,
    modelName: String,
    modifier: Modifier = Modifier
) {
    val progress = (currentFrame.toFloat() / totalFrames.coerceAtLeast(1)).coerceIn(0.01f, 1.0f)

    Box(
        modifier = modifier
            .background(Color(0xFF0B1017))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Draw Background based on Filter
            drawViewerBackground(filter, w, h)

            // 2. Draw 3D Printer Heated Bed Plate
            drawBuildPlate(filter, w, h)

            // 3. Draw Sliced Model Growing Layer by Layer
            drawPrintingModel(progress, filter, w, h, modelName)

            // 4. If Traditional mode, draw toolhead hovering; if Smooth mode, toolhead is parked at wipe tower
            drawToolhead(progress, mode, filter, w, h)
        }
    }
}

private fun DrawScope.drawViewerBackground(filter: TimelapseFilter, w: Float, h: Float) {
    when (filter) {
        TimelapseFilter.CYBER_BLUEPRINT -> {
            // Blueprint dark blue with grid lines
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF031024), Color(0xFF081C38))
                )
            )
            // Grid lines
            val step = 32f
            var x = 0f
            while (x < w) {
                drawLine(
                    color = Color(0x2200D2D3),
                    start = Offset(x, 0f),
                    end = Offset(x, h),
                    strokeWidth = 1f
                )
                x += step
            }
            var y = 0f
            while (y < h) {
                drawLine(
                    color = Color(0x2200D2D3),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
                y += step
            }
        }
        TimelapseFilter.NEON_GLOW -> {
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF1B0B2E), Color(0xFF0B0612)),
                    center = Offset(w * 0.5f, h * 0.6f),
                    radius = w * 0.8f
                )
            )
        }
        TimelapseFilter.SMOOTH_CINEMATIC -> {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF14171C), Color(0xFF08090C))
                )
            )
        }
        TimelapseFilter.VIBRANT_STUDIO -> {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF1A2332), Color(0xFF0F1622))
                )
            )
        }
        TimelapseFilter.ORIGINAL -> {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF121820), Color(0xFF0A0E14))
                )
            )
        }
    }
}

private fun DrawScope.drawBuildPlate(filter: TimelapseFilter, w: Float, h: Float) {
    val plateWidth = w * 0.72f
    val plateHeight = 24f
    val plateLeft = (w - plateWidth) / 2f
    val plateTop = h * 0.76f

    val plateColor = when (filter) {
        TimelapseFilter.CYBER_BLUEPRINT -> Color(0xFF0E305C)
        TimelapseFilter.NEON_GLOW -> Color(0xFF28113D)
        else -> Color(0xFF232930)
    }

    // Plate body
    drawRoundRect(
        color = plateColor,
        topLeft = Offset(plateLeft, plateTop),
        size = Size(plateWidth, plateHeight),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
    )

    // Plate top surface (PEI textured sheet golden/dark)
    val sheetColor = when (filter) {
        TimelapseFilter.CYBER_BLUEPRINT -> Color(0xFF00E5FF)
        TimelapseFilter.NEON_GLOW -> Color(0xFFFF007F)
        else -> Color(0xFFD4AF37)
    }
    drawLine(
        color = sheetColor,
        start = Offset(plateLeft + 4f, plateTop + 2f),
        end = Offset(plateLeft + plateWidth - 4f, plateTop + 2f),
        strokeWidth = 3f
    )

    // Calibration grid marks on build sheet
    val markSpacing = plateWidth / 8f
    for (i in 1..7) {
        val mx = plateLeft + i * markSpacing
        drawLine(
            color = Color(0x44FFFFFF),
            start = Offset(mx, plateTop + 2f),
            end = Offset(mx, plateTop + 8f),
            strokeWidth = 1.5f
        )
    }
}

private fun DrawScope.drawPrintingModel(
    progress: Float,
    filter: TimelapseFilter,
    w: Float,
    h: Float,
    modelName: String
) {
    val bedTop = h * 0.76f
    val maxModelHeight = h * 0.42f
    val currentHeight = maxModelHeight * progress
    val modelBaseY = bedTop
    val modelTopY = bedTop - currentHeight

    val centerX = w * 0.5f

    // Filament base colors according to filter
    val (primaryColor, accentColor, glowColor) = when (filter) {
        TimelapseFilter.CYBER_BLUEPRINT -> Triple(Color(0xFF00D2D3), Color(0xFF00E5FF), Color(0x6600E5FF))
        TimelapseFilter.NEON_GLOW -> Triple(Color(0xFFFF007F), Color(0xFF9D00FF), Color(0x88FF007F))
        TimelapseFilter.VIBRANT_STUDIO -> Triple(Color(0xFFFF7A00), Color(0xFF00AE42), Color(0x44FF7A00))
        TimelapseFilter.SMOOTH_CINEMATIC -> Triple(Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0x33FFFFFF))
        TimelapseFilter.ORIGINAL -> Triple(Color(0xFF00AE42), Color(0xFFFF9800), Color(0x4400AE42))
    }

    // Draw stacked extruded layer lines
    val layerCount = (progress * 48).toInt().coerceAtLeast(1)
    val layerHeight = currentHeight / layerCount

    for (i in 0 until layerCount) {
        val layerProg = i.toFloat() / 48f
        val layerY = modelBaseY - (i * layerHeight)

        // Shape profile: Benchy silhouette or polygonal geometry
        val widthFactor = when {
            layerProg < 0.35f -> 0.38f + (layerProg * 0.25f) // Hull width
            layerProg < 0.65f -> 0.26f + sin(layerProg * 10f) * 0.04f // Cabin width
            else -> 0.12f // Chimney width
        }
        val layerWidth = w * widthFactor
        val layerLeft = centerX - (layerWidth / 2f)

        val layerBrush = Brush.horizontalGradient(
            colors = listOf(
                primaryColor.copy(alpha = 0.85f),
                accentColor,
                primaryColor.copy(alpha = 0.85f)
            ),
            startX = layerLeft,
            endX = layerLeft + layerWidth
        )

        drawRoundRect(
            brush = layerBrush,
            topLeft = Offset(layerLeft, layerY - layerHeight),
            size = Size(layerWidth, layerHeight + 1f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2f, 2f)
        )
    }

    // Active layer glow (where nozzle just deposited molten plastic)
    if (progress < 0.99f) {
        val activeY = modelTopY
        val topWidth = when {
            progress < 0.35f -> 0.38f + (progress * 0.25f)
            progress < 0.65f -> 0.26f + sin(progress * 10f) * 0.04f
            else -> 0.12f
        } * w

        // Glowing molten bead
        drawRoundRect(
            brush = Brush.horizontalGradient(
                colors = listOf(glowColor, Color.White, glowColor),
                startX = centerX - (topWidth / 2f),
                endX = centerX + (topWidth / 2f)
            ),
            topLeft = Offset(centerX - (topWidth / 2f), activeY - 2f),
            size = Size(topWidth, 4f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2f, 2f)
        )
    }
}

private fun DrawScope.drawToolhead(
    progress: Float,
    mode: TimelapseMode,
    filter: TimelapseFilter,
    w: Float,
    h: Float
) {
    if (progress >= 1.0f) return

    val bedTop = h * 0.76f
    val maxModelHeight = h * 0.42f
    val currentHeight = maxModelHeight * progress
    val modelTopY = bedTop - currentHeight

    // If Smooth mode: toolhead is parked on the far right (wipe tower/purge chute)
    // If Traditional mode: toolhead is right on top of the model
    val toolheadX = if (mode == TimelapseMode.SMOOTH) {
        w * 0.82f // Parked at wipe tower
    } else {
        w * 0.5f + (sin(progress * 40f) * 40f) // Hovering
    }
    val toolheadY = modelTopY - 14f

    val nozzleColor = when (filter) {
        TimelapseFilter.CYBER_BLUEPRINT -> Color(0xFF00E5FF)
        else -> Color(0xFFCBD5E1)
    }

    // Draw Bambu Hotend Nozzle Cone
    val nozzlePath = Path().apply {
        moveTo(toolheadX - 12f, toolheadY - 24f)
        lineTo(toolheadX + 12f, toolheadY - 24f)
        lineTo(toolheadX + 4f, toolheadY)
        lineTo(toolheadX - 4f, toolheadY)
        close()
    }
    drawPath(nozzlePath, color = nozzleColor)

    // Glowing tip
    drawCircle(
        color = Color(0xFFFF5722),
        radius = 3.5f,
        center = Offset(toolheadX, toolheadY)
    )

    // If parked in Smooth mode, draw "PARKED (SMOOTH)" indicator line
    if (mode == TimelapseMode.SMOOTH) {
        drawLine(
            color = Color(0x6600AE42),
            start = Offset(toolheadX, toolheadY - 26f),
            end = Offset(toolheadX, bedTop),
            strokeWidth = 1.5f,
            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
        )
    }
}
