package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.TimelapseProject
import com.example.ui.screens.BambuConnectScreen
import com.example.ui.screens.CameraCaptureScreen
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.TimelapsePlayerScreen
import com.example.ui.theme.BambuGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PrintLapseViewModel

enum class AppScreen(val titleJp: String, val icon: ImageVector) {
    HOME("ホーム", Icons.Default.Home),
    PLAYER("再生/編集", Icons.Default.PlayCircleOutline),
    CAMERA("三脚撮影", Icons.Default.CameraAlt),
    GALLERY("一覧", Icons.Default.VideoLibrary),
    CONNECT("連携設定", Icons.Default.Router)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(
    viewModel: PrintLapseViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
    val selectedProject by viewModel.selectedProject.collectAsState()
    val toastNotification by viewModel.toastNotification.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastNotification) {
        toastNotification?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_bottom_nav"),
                containerColor = DarkSurface,
                contentColor = TextPrimary,
                tonalElevation = 8.dp
            ) {
                AppScreen.entries.forEach { screen ->
                    val isSelected = currentScreen == screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentScreen = screen },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.titleJp
                            )
                        },
                        label = {
                            Text(
                                text = screen.titleJp,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = BambuGreen,
                            indicatorColor = BambuGreen,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToPlayer = { project ->
                        if (project != null) {
                            viewModel.selectProject(project)
                        }
                        currentScreen = AppScreen.PLAYER
                    },
                    onNavigateToConnect = { currentScreen = AppScreen.CONNECT },
                    onNavigateToCamera = { currentScreen = AppScreen.CAMERA },
                    onNavigateToGallery = { currentScreen = AppScreen.GALLERY }
                )

                AppScreen.PLAYER -> TimelapsePlayerScreen(
                    viewModel = viewModel,
                    project = selectedProject,
                    onNavigateBack = { currentScreen = AppScreen.HOME }
                )

                AppScreen.CONNECT -> BambuConnectScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = AppScreen.HOME }
                )

                AppScreen.CAMERA -> CameraCaptureScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = AppScreen.HOME }
                )

                AppScreen.GALLERY -> GalleryScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = AppScreen.HOME },
                    onSelectProject = { project ->
                        viewModel.selectProject(project)
                        currentScreen = AppScreen.PLAYER
                    }
                )
            }
        }
    }
}
