package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PrintLapseDatabase
import com.example.data.local.PrinterEntity
import com.example.data.model.BambuPrinterType
import com.example.data.model.NetworkTestResult
import com.example.data.model.PrintStatus
import com.example.data.model.PrintTelemetry
import com.example.data.model.TimelapseFilter
import com.example.data.model.TimelapseMode
import com.example.data.model.TimelapseProject
import com.example.data.repository.PrintLapseRepository
import com.example.service.BambuPrinterManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class PrintLapseViewModel(application: Application) : AndroidViewModel(application) {

    private val database = PrintLapseDatabase.getInstance(application)
    private val repository = PrintLapseRepository(database.dao())

    val bambuManager = BambuPrinterManager(viewModelScope)
    val telemetry: StateFlow<PrintTelemetry> = bambuManager.telemetry

    val printers: StateFlow<List<PrinterEntity>> = repository.printers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val timelapses: StateFlow<List<TimelapseProject>> = repository.timelapses.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Active project in player
    private val _selectedProject = MutableStateFlow<TimelapseProject?>(null)
    val selectedProject: StateFlow<TimelapseProject?> = _selectedProject.asStateFlow()

    // Player state
    private val _currentFrame = MutableStateFlow(180)
    val currentFrame: StateFlow<Int> = _currentFrame.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _playbackFps = MutableStateFlow(30)
    val playbackFps: StateFlow<Int> = _playbackFps.asStateFlow()

    private val _isLooping = MutableStateFlow(true)
    val isLooping: StateFlow<Boolean> = _isLooping.asStateFlow()

    private val _activeFilter = MutableStateFlow(TimelapseFilter.ORIGINAL)
    val activeFilter: StateFlow<TimelapseFilter> = _activeFilter.asStateFlow()

    private val _isHudOverlayVisible = MutableStateFlow(true)
    val isHudOverlayVisible: StateFlow<Boolean> = _isHudOverlayVisible.asStateFlow()

    // Export state
    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _exportProgress = MutableStateFlow(0f)
    val exportProgress: StateFlow<Float> = _exportProgress.asStateFlow()

    private val _toastNotification = MutableStateFlow<String?>(null)
    val toastNotification: StateFlow<String?> = _toastNotification.asStateFlow()

    // LAN Connection settings
    private val _printerIp = MutableStateFlow("192.168.1.185")
    val printerIp: StateFlow<String> = _printerIp.asStateFlow()

    private val _printerAccessCode = MutableStateFlow("948216")
    val printerAccessCode: StateFlow<String> = _printerAccessCode.asStateFlow()

    private val _printerSerial = MutableStateFlow("01P00A381200384")
    val printerSerial: StateFlow<String> = _printerSerial.asStateFlow()

    private val _printerModel = MutableStateFlow(BambuPrinterType.P1S)
    val printerModel: StateFlow<BambuPrinterType> = _printerModel.asStateFlow()

    val networkTestResult: StateFlow<NetworkTestResult?> = bambuManager.networkTestResult
    val isTestingConnection: StateFlow<Boolean> = bambuManager.isTestingConnection

    private var playbackJob: Job? = null

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty(0)
        }

        bambuManager.onPrintCompletedListener = { completedTelemetry ->
            if (completedTelemetry.isAutoTimelapseEnabled) {
                autoGenerateAndSaveTimelapse(completedTelemetry)
            }
        }
    }

    fun updatePrinterConfig(ip: String, accessCode: String, serial: String, model: BambuPrinterType) {
        _printerIp.value = ip
        _printerAccessCode.value = accessCode
        _printerSerial.value = serial
        _printerModel.value = model
    }

    fun savePrinterConfig() {
        viewModelScope.launch {
            repository.savePrinter(
                PrinterEntity(
                    name = _printerModel.value.displayName,
                    printerType = _printerModel.value.name,
                    ipAddress = _printerIp.value,
                    accessCode = _printerAccessCode.value,
                    serialNumber = _printerSerial.value,
                    isAutoSyncEnabled = true,
                    isDefault = true
                )
            )
            _toastNotification.value = "プリンター設定を保存しました"
        }
    }

    fun runNetworkTest() {
        viewModelScope.launch {
            bambuManager.testConnection(_printerIp.value, _printerAccessCode.value)
        }
    }

    fun toggleAutoTimelapse(enabled: Boolean) {
        bambuManager.toggleAutoTimelapse(enabled)
    }

    fun toggleTimelapseMode() {
        val nextMode = if (telemetry.value.timelapseMode == TimelapseMode.SMOOTH) {
            TimelapseMode.TRADITIONAL
        } else {
            TimelapseMode.SMOOTH
        }
        bambuManager.setTimelapseMode(nextMode)
    }

    fun pauseResumePrint() {
        bambuManager.pausePrint()
    }

    fun startNewSimulationPrint(jobName: String = "Articulated_Gecko_Speed.3mf", layers: Int = 280) {
        bambuManager.startNewSimulatedPrint(
            jobName = jobName,
            totalLayers = layers,
            filament = "Bambu PLA Basic (Emerald Green)"
        )
        _toastNotification.value = "テスト造形を開始しました (Bambu Studio自動連携)"
    }

    fun generateTimelapseNow() {
        val current = telemetry.value
        viewModelScope.launch {
            _isExporting.value = true
            _exportProgress.value = 0.1f
            for (p in 2..10) {
                delay(120)
                _exportProgress.value = p / 10f
            }
            autoGenerateAndSaveTimelapse(current)
            _isExporting.value = false
        }
    }

    private fun autoGenerateAndSaveTimelapse(t: PrintTelemetry) {
        viewModelScope.launch {
            val total = t.currentLayer.coerceAtLeast(30)
            val videoSec = (total / 30).coerceAtLeast(5)
            val newProject = TimelapseProject(
                id = 0,
                title = t.jobName.removeSuffix(".3mf").removeSuffix(".gcode"),
                printerName = _printerModel.value.displayName,
                filament = t.filamentType,
                totalLayers = total,
                printDuration = "${t.elapsedMinutes}m",
                videoDurationSec = videoSec,
                frameCount = total,
                fps = 30,
                isBambuAutoGenerated = true,
                timelapseMode = t.timelapseMode,
                createdAt = System.currentTimeMillis(),
                nozzleTempAvg = t.nozzleTemp,
                bedTempAvg = t.bedTemp,
                fileSizeMb = String.format("%.1f", total * 0.05).toDoubleOrNull() ?: 12.0,
                notes = "Bambu Studio自動生成 (${t.timelapseMode.labelJp})"
            )
            val savedId = repository.saveTimelapse(newProject)
            _selectedProject.value = newProject.copy(id = savedId)
            _currentFrame.value = total
            _toastNotification.value = "タイムラプス動画が自動生成されました！ (${newProject.title})"
        }
    }

    fun selectProject(project: TimelapseProject) {
        _selectedProject.value = project
        _currentFrame.value = project.frameCount
        pausePlayback()
    }

    fun clearToast() {
        _toastNotification.value = null
    }

    // Playback control
    fun togglePlayPause() {
        if (_isPlaying.value) {
            pausePlayback()
        } else {
            startPlayback()
        }
    }

    fun seekFrame(frame: Int) {
        val maxFrame = _selectedProject.value?.frameCount ?: telemetry.value.totalLayers
        _currentFrame.value = frame.coerceIn(1, maxFrame)
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        if (_isPlaying.value) {
            startPlayback()
        }
    }

    fun setPlaybackFps(fps: Int) {
        _playbackFps.value = fps
        if (_isPlaying.value) {
            startPlayback()
        }
    }

    fun toggleLooping() {
        _isLooping.value = !_isLooping.value
    }

    fun setFilter(filter: TimelapseFilter) {
        _activeFilter.value = filter
    }

    fun toggleHudOverlay() {
        _isHudOverlayVisible.value = !_isHudOverlayVisible.value
    }

    private fun startPlayback() {
        playbackJob?.cancel()
        _isPlaying.value = true
        playbackJob = viewModelScope.launch {
            val maxFrame = _selectedProject.value?.frameCount ?: telemetry.value.totalLayers
            while (isActive && _isPlaying.value) {
                val delayMs = (1000.0 / (_playbackFps.value * _playbackSpeed.value)).toLong().coerceAtLeast(10L)
                delay(delayMs)
                val next = _currentFrame.value + 1
                if (next > maxFrame) {
                    if (_isLooping.value) {
                        _currentFrame.value = 1
                    } else {
                        _isPlaying.value = false
                        break
                    }
                } else {
                    _currentFrame.value = next
                }
            }
        }
    }

    private fun pausePlayback() {
        _isPlaying.value = false
        playbackJob?.cancel()
    }

    fun exportVideo(onComplete: (String) -> Unit) {
        viewModelScope.launch {
            _isExporting.value = true
            _exportProgress.value = 0f
            for (i in 1..20) {
                delay(70)
                _exportProgress.value = i / 20f
            }
            _isExporting.value = false
            val projectTitle = _selectedProject.value?.title ?: telemetry.value.jobName
            val filename = "${projectTitle}_BambuLapse.mp4"
            _toastNotification.value = "タイムラプス動画 ($filename) を書き出しました！"
            onComplete(filename)
        }
    }

    fun deleteTimelapse(id: Long) {
        viewModelScope.launch {
            repository.deleteTimelapse(id)
            if (_selectedProject.value?.id == id) {
                _selectedProject.value = null
            }
            _toastNotification.value = "タイムラプスを削除しました"
        }
    }
}
